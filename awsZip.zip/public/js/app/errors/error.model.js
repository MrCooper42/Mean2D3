export var Error = (function () {
    function Error(title, message) {
        this.title = title;
        this.message = message;
    }
    return Error;
}());
//# sourceMappingURL=error.model.js.map